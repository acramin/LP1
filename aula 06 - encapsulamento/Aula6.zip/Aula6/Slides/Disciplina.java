package Slides;

public class Disciplina {
    private String nome;
    private int qtdAlunosMatriculados;

    public void nomear(String n){
        nome = n;
    }

    public int qtdAlunos(){
        return qtdAlunosMatriculados;
    }
}
