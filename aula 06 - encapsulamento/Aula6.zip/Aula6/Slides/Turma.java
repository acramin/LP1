package Slides;

public class Turma {
    
    public void matricula(Aluno aluno, Disciplina disciplina){
    }
}
