public class ex1 {

    public static void main(String[] args) {
        
        int n = 0;

        while (n<=20) {
            System.out.println(n);
            n = n +2;
        }

    }
}