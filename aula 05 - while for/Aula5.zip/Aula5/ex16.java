public class ex16 {
    public static void main(String[] args) {
        
        double pol = 2.54; // 1 pol = 2.54 cm
        
        for(int i = 1; i <= 20; i ++){
            System.out.println(i + " pol = " + (i * pol) + "cm ");
        }
    }
}

